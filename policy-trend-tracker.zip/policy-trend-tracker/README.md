# Policy Trend Tracker

A daily digest that surfaces the **top 7 trending public policy themes** by combining RSS headlines, Google Trends, and live X (Twitter) posts — then emails or Slacks them to you as a formatted digest.

Bring your own AI provider (OpenAI, Anthropic, Grok, Ollama) and your own RSS feeds.

---

## How it works

```
RSS feeds (configurable)  ──┐
Google Trends             ──┼──► AI analysis ──► Email / Slack / stdout
X posts via Grok          ──┘
```

---

## Quickstart

```bash
git clone https://github.com/your-username/policy-trend-tracker
cd policy-trend-tracker
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Fill in .env (see Configuration below)
python main.py
```

---

## Configuration

All config lives in `.env`. Copy `.env.example` to get started.

### AI Runner (`AI_RUNNER`)

| Value | Provider | Setup |
|---|---|---|
| `gemini_cli` (default) | Google Gemini | `npm install -g @google/gemini-cli` then `gemini auth` |
| `openai_compat` | Any OpenAI-compatible API | Set `AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL` |

**OpenAI-compatible providers:**

| Provider | `AI_BASE_URL` | `AI_MODEL` example |
|---|---|---|
| OpenAI | `https://api.openai.com/v1` | `gpt-4o` |
| Anthropic | `https://api.anthropic.com/v1` | `claude-opus-4-7` |
| xAI (Grok) | `https://api.x.ai/v1` | `grok-3` |
| Ollama (local) | `http://localhost:11434/v1` | `llama3` |

### X / Twitter data (`GROK_API_KEY`)

Grok has real-time access to X posts. Get a key at [console.x.ai](https://console.x.ai).  
This is optional — the tracker still runs without it.

### Output (`OUTPUT`)

| Value | What it does | Required env vars |
|---|---|---|
| `email` (default) | HTML digest via Gmail SMTP | `GMAIL_SENDER`, `GMAIL_APP_PASSWORD`, `GMAIL_RECIPIENT` |
| `stdout` | Prints to terminal | — |
| `slack` | Posts to a Slack channel | `SLACK_WEBHOOK_URL` |

**Gmail App Password:** Google account → Security → App passwords (requires 2FA enabled).  
**Slack webhook:** [api.slack.com/messaging/webhooks](https://api.slack.com/messaging/webhooks)

### RSS Feeds (`RSS_FEEDS`)

Leave unset to use the default 4 Indian outlets (The Hindu, Economic Times, NDTV, Indian Express).  
Supply a comma-separated list of RSS URLs to use your own:

```
RSS_FEEDS=https://feeds.bbci.co.uk/news/rss.xml,https://rss.nytimes.com/services/xml/rss/nyt/World.xml
```

---

## Running on a schedule with GitHub Actions

No server required — fork the repo and let GitHub run it daily.

1. Fork this repo
2. Go to **Settings → Secrets and variables → Actions**
3. Add secrets matching your `.env` (at minimum: `AI_RUNNER`, `AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL`, `OUTPUT`, and your output credentials)
4. The workflow at `.github/workflows/daily.yml` runs automatically at **9:00 AM IST** every day
5. Trigger a manual run anytime via **Actions → Daily Policy Digest → Run workflow**

> **Note:** Use `AI_RUNNER=openai_compat` for GitHub Actions — `gemini_cli` requires interactive OAuth and won't work in CI.

---

## Project structure

```
├── main.py                  # Orchestrator — reads config, runs pipeline
├── config.py                # RSS feed defaults + env override
├── fetchers/
│   ├── rss.py               # Parses RSS feeds, filters last 24h
│   ├── trends.py            # Google Trends via pytrends (optional)
│   └── grok.py              # Trending X posts via Grok API (optional)
├── runners/
│   ├── gemini_cli.py        # Gemini CLI subprocess runner
│   └── openai_compat.py     # OpenAI-compatible API runner
├── outputs/
│   ├── email.py             # HTML digest via Gmail SMTP
│   ├── stdout.py            # Print to terminal
│   └── slack.py             # Slack webhook
├── .github/workflows/
│   └── daily.yml            # GitHub Actions schedule
├── .env.example             # Config template
└── requirements.txt
```

---

## License

MIT
