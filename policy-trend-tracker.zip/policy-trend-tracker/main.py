import os
import sys
from dotenv import load_dotenv

load_dotenv()

# Re-evaluate RSS_FEEDS after .env is loaded so env overrides take effect
import config as _cfg
from config import get_rss_feeds
_cfg.RSS_FEEDS = get_rss_feeds()

from fetchers.rss import fetch_rss
from fetchers.trends import fetch_trends
from fetchers.grok import fetch_x_posts


def _get_runner():
    name = os.environ.get("AI_RUNNER", "claude_cli")
    if name == "claude_cli":
        from runners import claude_cli
        return claude_cli.run
    if name == "gemini_cli":
        from runners import gemini_cli
        return gemini_cli.run
    if name == "openai_compat":
        from runners import openai_compat
        return openai_compat.run
    print(f"Unknown AI_RUNNER '{name}', defaulting to claude_cli")
    from runners import claude_cli
    return claude_cli.run


def _get_output():
    name = os.environ.get("OUTPUT", "email")
    if name == "email":
        from outputs import email
        return email.send
    if name == "stdout":
        from outputs import stdout
        return stdout.send
    if name == "slack":
        from outputs import slack
        return slack.send
    print(f"Unknown OUTPUT '{name}', defaulting to stdout")
    from outputs import stdout
    return stdout.send


def main():
    run = _get_runner()
    send = _get_output()

    print("Fetching RSS feeds...")
    articles = fetch_rss()
    print(f"  {len(articles)} articles")

    print("Fetching Google Trends...")
    trends = fetch_trends()
    print(f"  {len(trends)} trending terms")

    print("Fetching X posts via Grok...")
    x_posts = fetch_x_posts()
    print(f"  {len(x_posts)} X posts")

    print(f"Running AI analysis ({os.environ.get('AI_RUNNER', 'claude_cli')})...")
    themes = run(articles, trends, x_posts)
    print(f"  {len(themes)} themes identified")

    print(f"Sending output ({os.environ.get('OUTPUT', 'email')})...")
    send(themes)
    print("Done.")


if __name__ == "__main__":
    main()
