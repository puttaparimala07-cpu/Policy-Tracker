import os

_DEFAULT_FEEDS = [
    ("The Hindu",       "https://www.thehindu.com/news/national/feeder/default.rss"),
    ("Economic Times",  "https://economictimes.indiatimes.com/rssfeedstopstories.cms"),
    ("NDTV",            "https://feeds.feedburner.com/ndtvnews-india-news"),
    ("Indian Express",  "https://indianexpress.com/section/india/feed/"),
]


def get_rss_feeds() -> list[tuple[str, str]]:
    raw = os.environ.get("RSS_FEEDS", "")
    if not raw.strip():
        return _DEFAULT_FEEDS
    feeds = []
    for url in raw.split(","):
        url = url.strip()
        if url:
            # Use domain as source name when user supplies their own feeds
            from urllib.parse import urlparse
            domain = urlparse(url).netloc.replace("www.", "")
            feeds.append((domain, url))
    return feeds


# Keep as module-level for backward compat with fetchers/rss.py
RSS_FEEDS = get_rss_feeds()
