import json
import os
import re
from datetime import date

_PROMPT = """
Today is {date}. You are an Indian public policy analyst.

Identify the 7 most significant trending Indian public policy themes today based on the data below.

RSS headlines from major Indian outlets, each with its source URL:
{rss_headlines}

Trending Google searches in India today:
{trend_terms}

Trending X (Twitter) posts about Indian policy:
{x_posts}

CRITICAL: The "sources" field MUST contain only URLs that appear verbatim in the headlines list above. Do NOT invent, modify, or guess URLs. If a theme has no matching source URL in the list, use an empty array [].

Output ONLY a JSON array of 7 objects — no markdown, no explanation, no other text:
[
  {{
    "rank": 1,
    "theme": "short theme name",
    "category": "one of: Economy, Healthcare, Agriculture, Education, Infrastructure, Defense, Climate, Parliament",
    "why_trending": "1-2 sentences explaining why this is trending today",
    "key_takeaway": "1 sentence on the core issue or development",
    "sources": ["url1", "url2"]
  }}
]
""".strip()


def _extract_json(text: str) -> list:
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    match = re.search(r"\[.*\]", text, re.DOTALL)
    if match:
        return json.loads(match.group())
    raise ValueError(f"No JSON array in API output:\n{text[:600]}")


def run(rss_articles: list[dict], trends: list[str], x_posts: list[str]) -> list[dict]:
    from openai import OpenAI

    client = OpenAI(
        api_key=os.environ["AI_API_KEY"],
        base_url=os.environ.get("AI_BASE_URL", "https://api.openai.com/v1"),
    )
    model = os.environ.get("AI_MODEL", "gpt-4o")

    headlines = "\n".join(
        f"- [{a['source']}] {a['title']} — {a['url']}" for a in rss_articles[:40]
    ) or "unavailable"
    trend_terms = ", ".join(trends[:20]) if trends else "unavailable"
    x_summary = "\n".join(f"- {p}" for p in x_posts[:20]) if x_posts else "unavailable"

    prompt = _PROMPT.format(
        date=date.today().strftime("%B %d, %Y"),
        rss_headlines=headlines,
        trend_terms=trend_terms,
        x_posts=x_summary,
    )

    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        timeout=120,
    )
    return _extract_json(response.choices[0].message.content or "")
