# Getting Started

This project includes a **Claude Code skill** that handles installation and daily runs for you. You won't need to type any terminal commands — Claude will do that on your behalf and ask you questions in plain English.

**Estimated first-time setup:** ~10 minutes. After that, daily runs take ~30 seconds.

---

## Step 1 — Install Claude Code

Claude Code is a free desktop app from Anthropic. Download and install it from:

**https://claude.com/claude-code**

Sign in with your Anthropic account (or create one — it's free).

## Step 2 — Open this project in Claude Code

1. Unzip the project folder you received (if you haven't already).
2. Open **Claude Code**.
3. Use **File → Open Folder** (or the equivalent in the app) and select the unzipped project folder.

Claude Code will automatically detect the included skill.

## Step 3 — Run the skill

In the Claude Code chat box, type:

```
/policy-tracker
```

…and press Enter. Claude will:

1. Check what's already installed on your computer.
2. Walk you through any missing setup (Python, dependencies, API key).
3. Run the tracker and show you the top 7 trending policy themes.

The AI analysis runs through Claude Code itself, so **you don't need a separate AI API key**. Claude will optionally offer to add a Grok key for live X/Twitter data — you can skip that and the tracker still works on news headlines and Google Trends alone.

## Step 4 — Daily use

Anytime you want a fresh digest, just open the project in Claude Code again and type `/policy-tracker`. Setup only happens once.

---

## If something goes wrong

Just tell Claude what you're seeing — it can troubleshoot most issues directly. If you get truly stuck, send Ram the chat transcript and he can help.
