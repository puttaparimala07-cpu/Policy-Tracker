import json
import re
import subprocess
from datetime import date

_PROMPT = """
Today is {date}. You are an Indian public policy analyst.

Search Google News for today's top Indian public policy news.
Also consider these RSS headlines from major Indian outlets:
{rss_headlines}

Trending Google searches in India today:
{trend_terms}

Identify the 7 most significant trending Indian public policy themes today.
Output ONLY a JSON array of 7 objects — no markdown, no explanation, no other text:
[
  {{
    "rank": 1,
    "theme": "short theme name",
    "category": "one of: Economy, Healthcare, Agriculture, Education, Infrastructure, Defense, Climate, Parliament",
    "why_trending": "1-2 sentences explaining why this is trending today",
    "key_takeaway": "1 sentence on the core issue or development",
    "sources": ["url1", "url2"]
  }}
]
""".strip()


def _extract_json(text: str) -> list:
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    match = re.search(r"\[.*\]", text, re.DOTALL)
    if match:
        return json.loads(match.group())
    raise ValueError(f"No JSON array in Gemini output:\n{text[:600]}")


def run_gemini(rss_articles: list[dict], trend_terms: list[str]) -> list[dict]:
    headlines = "\n".join(
        f"- [{a['source']}] {a['title']}" for a in rss_articles[:40]
    ) or "unavailable"

    trends = ", ".join(trend_terms[:20]) if trend_terms else "unavailable"

    prompt = _PROMPT.format(
        date=date.today().strftime("%B %d, %Y"),
        rss_headlines=headlines,
        trend_terms=trends,
    )

    result = subprocess.run(
        ["gemini", "--skip-trust", "--yolo", "-p", prompt],
        capture_output=True, text=True, timeout=120,
    )
    return _extract_json(result.stdout.strip())


if __name__ == "__main__":
    themes = run_gemini([], [])
    print(json.dumps(themes, indent=2))
