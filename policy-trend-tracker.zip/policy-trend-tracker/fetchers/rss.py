import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import feedparser
from datetime import datetime, timedelta, timezone
from config import RSS_FEEDS


def fetch_rss() -> list[dict]:
    cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
    articles, seen = [], set()

    for source, url in RSS_FEEDS:
        feed = feedparser.parse(url)
        for entry in feed.entries:
            link = entry.get("link", "")
            if not link or link in seen:
                continue
            seen.add(link)

            parsed = entry.get("published_parsed")
            if parsed:
                pub_dt = datetime(*parsed[:6], tzinfo=timezone.utc)
                if pub_dt < cutoff:
                    continue

            articles.append({
                "title":   entry.get("title", "").strip(),
                "summary": entry.get("summary", "")[:200].strip(),
                "url":     link,
                "source":  source,
            })

    return articles


if __name__ == "__main__":
    import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    items = fetch_rss()
    print(f"{len(items)} articles fetched")
    for a in items[:5]:
        print(f"  [{a['source']}] {a['title']}")
