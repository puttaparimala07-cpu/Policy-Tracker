import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def fetch_x_posts() -> list[str]:
    api_key = os.environ.get("GROK_API_KEY", "")
    if not api_key:
        print("  X/Grok unavailable: GROK_API_KEY not set")
        return []

    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key, base_url="https://api.x.ai/v1")

        response = client.chat.completions.create(
            model=os.environ.get("GROK_MODEL", "grok-3"),
            messages=[{
                "role": "user",
                "content": (
                    "Search X (Twitter) for the top 20 trending posts or discussions "
                    "about Indian public policy, government, or politics from the last 24 hours. "
                    "Return each as a one-line summary starting with a dash (-). "
                    "No intro, no explanation — just the list."
                ),
            }],
        )
        text = response.choices[0].message.content or ""
        posts = [line.lstrip("- ").strip() for line in text.splitlines() if line.strip().startswith("-")]
        return posts[:20]
    except Exception as e:
        print(f"  X/Grok unavailable: {e}")
        return []


if __name__ == "__main__":
    posts = fetch_x_posts()
    print(f"{len(posts)} X posts fetched")
    for p in posts[:5]:
        print(f"  {p}")
