import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import feedparser

_TRENDS_RSS = "https://trends.google.com/trending/rss?geo=IN"


def fetch_trends() -> list[str]:
    try:
        feed = feedparser.parse(_TRENDS_RSS)
        if feed.bozo and not feed.entries:
            raise RuntimeError(f"feed parse error: {feed.bozo_exception}")
        return [e.title.strip() for e in feed.entries if e.get("title")][:20]
    except Exception as e:
        print(f"  trends unavailable: {e}")
        return []


if __name__ == "__main__":
    terms = fetch_trends()
    print(f"{len(terms)} trending terms: {terms[:10]}")
