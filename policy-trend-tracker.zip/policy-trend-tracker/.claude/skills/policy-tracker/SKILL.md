---
name: policy-tracker
description: Set up and run the Policy Trend Tracker — a daily digest that surfaces the top 7 trending public policy themes from RSS feeds, Google Trends, and live X (Twitter) posts. Use this skill when the user wants to install the tracker for the first time, run the daily digest, reconfigure it, or troubleshoot it. The skill handles all terminal commands on the user's behalf — they should never need to type shell commands themselves.
---

# Policy Trend Tracker — Setup & Run

You are helping a **non-technical user** install and run the Policy Trend Tracker. They will not type any terminal commands themselves — you run everything via the Bash tool, explain what you're doing in plain language, and ask for input only when you need information that cannot be detected automatically (e.g. an API key).

## Tone

- Friendly and reassuring. The user has never written code before.
- Never use jargon without explaining it (e.g. say "a virtual environment — basically a clean sandbox for this project's Python libraries").
- Show progress: "Step 2 of 5: Installing dependencies — this takes about a minute."
- If something fails, never blame the user. Diagnose and fix it.

## Detect what state we're in

Before doing anything, check the project state by running these in parallel:

1. `ls` in the project root — confirm `main.py`, `requirements.txt`, `.env.example` exist
2. `test -d venv && echo "venv exists" || echo "no venv"` — is a virtual environment already set up?
3. `test -f .env && echo "env exists" || echo "no env"` — is `.env` configured?
4. `python3 --version 2>/dev/null || python --version 2>/dev/null || echo "no python"` — is Python installed?

Based on results, branch into one of:

- **First-time setup** — no venv, no .env, or no Python → run the Setup Flow below.
- **Ready to run** — venv exists AND .env exists with a non-empty `AI_API_KEY` → run the Run Flow.
- **Partial state** — venv exists but .env missing (or vice versa) → resume setup from the missing step.

Tell the user up-front which flow you're in. Example: *"Looks like this is a fresh install — I'll walk you through one-time setup, which takes about 10 minutes. After this, running it daily takes ~30 seconds."*

---

## Setup Flow

### Step 1 — Python check

If `python3 --version` (Mac/Linux) or `python --version` (Windows) returns 3.10 or higher, continue. Otherwise:

- Tell the user Python isn't installed (or is too old) and they need to install it manually from [python.org/downloads](https://www.python.org/downloads/).
- On Windows, emphasize they must check **"Add Python to PATH"** in the installer.
- Stop the skill here and ask them to come back once Python is installed.

### Step 2 — Virtual environment

Detect the OS via `uname -s` (Darwin/Linux = Mac/Linux, anything else assume Windows). Run:

- **Mac/Linux:** `python3 -m venv venv`
- **Windows:** `python -m venv venv`

This creates a folder called `venv` inside the project. Tell the user: *"I just created a sandbox for this project's libraries so they don't interfere with anything else on your computer."*

### Step 3 — Install dependencies

Run dependency install using the venv's pip directly (avoids needing to "activate"):

- **Mac/Linux:** `./venv/bin/pip install -r requirements.txt`
- **Windows:** `venv\Scripts\pip install -r requirements.txt`

This takes ~30–60 seconds. Show the user a "this may take a minute" message before running.

### Step 4 — Collect the Grok API key (optional)

The AI analysis runs via the Claude Code CLI itself — **no separate AI API key needed**. The user is already signed into Claude Code, so the tracker uses that login for free.

The only key the user might want is a **Grok API key** for live X/Twitter posts:

> *Optionally, you can add a Grok API key from console.x.ai. This adds live X/Twitter posts to the analysis alongside news headlines and Google Trends. The tracker works fine without it — just skip if you don't want to bother. A Grok key starts with `xai-`.*

Then ask: *"Paste your Grok key (starts with `xai-`), or type 'skip':"*

### Step 5 — Write the .env file

Use the Write tool to create `.env` in the project root with this content:

```
AI_RUNNER=claude_cli

GROK_API_KEY=<their-grok-key-or-empty>
GROK_MODEL=grok-3

OUTPUT=stdout
```

If they skipped Grok, leave `GROK_API_KEY=` empty.

### Step 6 — First run

Tell the user: *"Setup is done! Running the tracker for the first time — this takes about a minute."* Then proceed to the Run Flow.

---

## Run Flow

Run the tracker using the venv's Python directly (no activation needed):

- **Mac/Linux:** `./venv/bin/python main.py`
- **Windows:** `venv\Scripts\python main.py`

Stream the output. When it finishes, summarize what the user is seeing if the output is dense, and ask if they want to:
- Run it again later (just invoke this skill again)
- Switch to email delivery instead of terminal output (explain they need a Gmail App Password; offer to walk through it)
- Customize the RSS sources

---

## Common failures and fixes

- **`ModuleNotFoundError`** — venv is incomplete. Re-run `./venv/bin/pip install -r requirements.txt`.
- **`401 Unauthorized` from Grok** — key is wrong or expired. Ask the user to re-paste it; update `.env` via the Edit tool.
- **`claude: command not found` from the runner** — Claude Code isn't on the PATH. Since this skill is running, Claude Code is installed, but the CLI binary may not be linked. Tell the user to open Claude Code and run `/install` or follow the CLI install instructions at claude.com/claude-code.
- **`ssl.SSLError` / network errors** — likely a corporate firewall or proxy. Ask the user if they're on a work/university network with restrictions.
- **Empty digest** — the RSS feeds may have nothing fresh in the last 24h. Suggest running again later, or ask if they want to customize the feeds.
- **`pip install` fails on Windows with build errors** — the user may be missing the Microsoft Visual C++ Build Tools. Point them to https://visualstudio.microsoft.com/visual-cpp-build-tools/ and tell them to come back after installing.

## Important guardrails

- **Never run `pip install` outside the venv.** Always use `./venv/bin/pip` (Mac/Linux) or `venv\Scripts\pip` (Windows).
- **Never echo the user's API keys back to them in chat after they paste them.** Confirm with "Got it, key saved" — not by repeating the key.
- **If `.env` already exists with real values, don't overwrite it without confirming first.** Ask: "Looks like .env is already configured. Reconfigure from scratch, or keep existing settings?"
- **Don't delete the `venv/` folder** unless the user explicitly asks to start over.
