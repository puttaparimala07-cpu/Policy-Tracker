import os
import smtplib
from datetime import date
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

_CATEGORY_COLOR = {
    "Economy":        "#0ea5e9",
    "Healthcare":     "#10b981",
    "Agriculture":    "#84cc16",
    "Education":      "#8b5cf6",
    "Infrastructure": "#f59e0b",
    "Defense":        "#ef4444",
    "Climate":        "#14b8a6",
    "Parliament":     "#6366f1",
}


def _theme_card(t: dict) -> str:
    color = _CATEGORY_COLOR.get(t.get("category", ""), "#6e6e73")
    sources = "".join(
        f'<a href="{s}" style="color:#0071e3;margin-right:10px;font-size:13px;">Source {i+1}</a>'
        for i, s in enumerate(t.get("sources") or [])
    )
    return f"""
<div style="background:#fff;border-radius:10px;padding:20px;margin-bottom:14px;box-shadow:0 1px 4px rgba(0,0,0,0.08);">
  <div style="margin-bottom:8px;">
    <span style="font-size:18px;font-weight:700;color:#1d1d1f;">#{t['rank']}&nbsp;</span>
    <span style="background:{color};color:#fff;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;">{t.get('category','')}</span>
  </div>
  <div style="font-size:16px;font-weight:600;color:#1d1d1f;margin-bottom:6px;">{t['theme']}</div>
  <div style="font-size:14px;color:#3c3c43;margin-bottom:4px;"><b>Why trending:</b> {t.get('why_trending','')}</div>
  <div style="font-size:14px;color:#3c3c43;margin-bottom:10px;">{t.get('key_takeaway','')}</div>
  {sources}
</div>"""


def send(themes: list[dict]) -> None:
    today     = date.today().strftime("%B %d, %Y")
    sender    = os.environ["GMAIL_SENDER"]
    password  = os.environ["GMAIL_APP_PASSWORD"]
    recipient = os.environ["GMAIL_RECIPIENT"]

    cards = "".join(_theme_card(t) for t in themes)
    html = f"""<html><body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f5f5f7;padding:24px;">
<div style="max-width:660px;margin:0 auto;">
  <h1 style="font-size:22px;color:#1d1d1f;margin-bottom:4px;">Indian Policy Trends</h1>
  <p style="color:#6e6e73;font-size:14px;margin-bottom:22px;">{today}</p>
  {cards}
  <p style="color:#aeaeb2;font-size:11px;margin-top:20px;">policy-trend-tracker</p>
</div>
</body></html>"""

    msg = MIMEMultipart("alternative")
    msg["Subject"] = f"Indian Policy Trends — {today}"
    msg["From"]    = sender
    msg["To"]      = recipient
    msg.attach(MIMEText(html, "html"))

    with smtplib.SMTP("smtp.gmail.com", 587) as smtp:
        smtp.starttls()
        smtp.login(sender, password)
        smtp.sendmail(sender, recipient, msg.as_string())
