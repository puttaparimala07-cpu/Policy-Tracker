import os
import json
import requests
from datetime import date


def send(themes: list[dict]) -> None:
    webhook_url = os.environ["SLACK_WEBHOOK_URL"]
    today = date.today().strftime("%B %d, %Y")

    blocks = [
        {"type": "header", "text": {"type": "plain_text", "text": f"Indian Policy Trends — {today}"}},
    ]
    for t in themes:
        blocks.append({"type": "divider"})
        blocks.append({
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": (
                    f"*#{t['rank']} {t['theme']}* `{t.get('category', '')}`\n"
                    f"*Why trending:* {t.get('why_trending', '')}\n"
                    f"{t.get('key_takeaway', '')}"
                ),
            },
        })

    resp = requests.post(webhook_url, json={"blocks": blocks}, timeout=10)
    resp.raise_for_status()
