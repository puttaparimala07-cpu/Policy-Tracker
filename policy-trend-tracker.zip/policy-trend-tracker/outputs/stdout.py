from datetime import date


def send(themes: list[dict]) -> None:
    print(f"\n=== Indian Policy Trends — {date.today().strftime('%B %d, %Y')} ===\n")
    for t in themes:
        print(f"#{t['rank']} [{t.get('category', '')}] {t['theme']}")
        print(f"  Why trending: {t.get('why_trending', '')}")
        print(f"  Key takeaway: {t.get('key_takeaway', '')}")
        for i, s in enumerate(t.get("sources") or []):
            print(f"  Source {i+1}: {s}")
        print()
